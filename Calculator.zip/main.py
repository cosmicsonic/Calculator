import math
val3 = input("Enter a function: ")
if val3 != "qdeq":
  val1 = input("Enter your first set of numbers 1: ")
  val2 = input("Enter your second set of numbers 2: ")
if val3 == "qdeq":
  valqd1 = input("Enter your 'a' value:")
  valqd2 = input("Enter your 'b' value:")
  valqd3 = input("Enter your 'c' value:")

if val3 == "dis" or val3 == "slo":
  split_string1 = val1.split(",", 1)
  split_string2 = val2.split(",", 1)
  val1sub1 = split_string1[0]
  val1sub2 = split_string1[1]
  val2sub1 = split_string2[0]
  val2sub2 = split_string2[1]
  num1 = abs(int(val1sub1)-int(val2sub1))
  num2 = abs(int(val1sub2)-int(val2sub2))

  if val3 == "dis":
    int1 = num1*num1
    int2 = num2*num2
    ans1 = math.sqrt(int1+int2)
    print(ans1)
  elif val3 == "slo":
    ans2 = num2/num1
    print(ans2)

elif val3 == "add":
  print(int(val1)+int(val2))

elif val3 == "sub":
  if val1>val2:
    print(int(val1)-int(val2))
  else:
    print(int(val2)-int(val1))

elif val3 == "mul":
  print(int(val1)*int(val2))
elif val3 == "div":
  print(int(val1)/int(val2))
elif val3 == "squ":
  print(math.sqrt(int(val1)))
elif val3 == "exp":
  print(int(val1)**int(val2))
# elif val3 == "qdeq":
#   a = int(valqd1)
#   b = int(valqd2)
#   c = int(valqd3)
#   ans = "x = " + str((-b)/2*a) + "±" + str((math.sqrt(b**2-(4*a*c)))/2*a)) 
#   print(ans)
else:
  print("FUNCTION INVALID")